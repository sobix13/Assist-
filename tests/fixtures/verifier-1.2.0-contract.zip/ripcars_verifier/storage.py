from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import time
from pathlib import Path

from .config import canonical, defaults, validate, wallet_kinds,account_kinds


class Conflict(ValueError):
    pass


SCHEMA = '''
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT OR IGNORE INTO meta VALUES('schema_version','1');
CREATE TABLE IF NOT EXISTS settings(guild INTEGER PRIMARY KEY,revision INTEGER NOT NULL,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,guild INTEGER NOT NULL,actor INTEGER NOT NULL,action TEXT NOT NULL,detail TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS links(guild INTEGER NOT NULL,user INTEGER NOT NULL,kind TEXT NOT NULL,identity TEXT NOT NULL,active INTEGER NOT NULL,created REAL NOT NULL,PRIMARY KEY(guild,kind,identity));
CREATE INDEX IF NOT EXISTS links_user ON links(guild,user,active);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,guild INTEGER NOT NULL,user INTEGER NOT NULL,purpose TEXT NOT NULL,expires REAL NOT NULL,message TEXT,wallet TEXT,used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS transfer_proofs(id TEXT PRIMARY KEY,guild INTEGER NOT NULL,user INTEGER NOT NULL,wallet TEXT NOT NULL,mint TEXT NOT NULL,program TEXT NOT NULL,decimals INTEGER NOT NULL,raw_amount TEXT NOT NULL,slot INTEGER NOT NULL,created REAL NOT NULL,expires REAL NOT NULL,used INTEGER NOT NULL DEFAULT 0,signature TEXT NOT NULL DEFAULT '',next_check REAL NOT NULL DEFAULT 0);
CREATE UNIQUE INDEX IF NOT EXISTS transfer_proof_wallet ON transfer_proofs(guild,wallet) WHERE used=0;
CREATE UNIQUE INDEX IF NOT EXISTS transfer_proof_user ON transfer_proofs(guild,user) WHERE used=0;
CREATE UNIQUE INDEX IF NOT EXISTS transfer_proof_signature ON transfer_proofs(signature) WHERE signature<>'';
CREATE TABLE IF NOT EXISTS ledger(guild INTEGER NOT NULL,event_id TEXT NOT NULL,user INTEGER NOT NULL,wallet TEXT NOT NULL,usd_micros INTEGER NOT NULL,source TEXT NOT NULL,proof TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(guild,event_id));
CREATE INDEX IF NOT EXISTS ledger_user ON ledger(guild,user);
CREATE TABLE IF NOT EXISTS observations(guild INTEGER NOT NULL,wallet TEXT NOT NULL,signature TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(guild,wallet,signature));
CREATE TABLE IF NOT EXISTS checkpoints(guild INTEGER NOT NULL,wallet TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(guild,wallet));
CREATE TABLE IF NOT EXISTS snapshots(guild INTEGER NOT NULL,user INTEGER NOT NULL,value TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS jobs(guild INTEGER NOT NULL,user INTEGER NOT NULL,next_run REAL NOT NULL,failures INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS monitoring(guild INTEGER,user INTEGER,active INTEGER NOT NULL,PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS job_requests(guild INTEGER,user INTEGER,kinds TEXT NOT NULL,version INTEGER NOT NULL,PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS point_batches(id INTEGER PRIMARY KEY,guild INTEGER NOT NULL,actor INTEGER NOT NULL,status TEXT NOT NULL,created REAL NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS point_batch_running ON point_batches(guild) WHERE status='running';
CREATE TABLE IF NOT EXISTS point_batch_members(batch INTEGER,user INTEGER,state TEXT NOT NULL DEFAULT 'pending',error TEXT NOT NULL DEFAULT '',PRIMARY KEY(batch,user));
CREATE TABLE IF NOT EXISTS role_grants(guild INTEGER NOT NULL,user INTEGER NOT NULL,role INTEGER NOT NULL,state TEXT NOT NULL,PRIMARY KEY(guild,user,role));
CREATE TABLE IF NOT EXISTS deliveries(guild INTEGER NOT NULL,event_id TEXT NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,state TEXT NOT NULL,message INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,next_run REAL NOT NULL,created REAL NOT NULL,PRIMARY KEY(guild,event_id));
CREATE TABLE IF NOT EXISTS webhook_ids(scope TEXT NOT NULL,event_id TEXT NOT NULL,expires REAL NOT NULL,PRIMARY KEY(scope,event_id));
'''


class Store:
    def __init__(self,path):
        self.path=Path(path); self.lock=asyncio.Lock()

    def connect(self):
        c=sqlite3.connect(self.path,timeout=15); c.row_factory=sqlite3.Row
        c.execute('PRAGMA busy_timeout=15000'); c.execute('PRAGMA foreign_keys=ON')
        return c

    async def run(self,fn):
        async with self.lock:
            def execute():
                c=self.connect()
                try:
                    c.execute('BEGIN IMMEDIATE'); result=fn(c); c.commit(); return result
                except BaseException:
                    c.rollback(); raise
                finally: c.close()
            task=asyncio.create_task(asyncio.to_thread(execute))
            try:return await asyncio.shield(task)
            except asyncio.CancelledError:
                try:await task
                finally:raise

    async def open(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        def init():
            with self.connect() as c:
                if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='meta'").fetchone():
                    old=c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
                    if not old or old[0]!='1': raise Conflict('Unsupported database schema. Install a compatible release; no migration was applied.')
                c.execute('PRAGMA journal_mode=WAL'); c.executescript(SCHEMA)
                if not c.execute("SELECT 1 FROM meta WHERE key='role_monitor_policy'").fetchone():
                    for row in c.execute('SELECT guild,value FROM settings').fetchall():
                        cfg=json.loads(row['value']);cfg['sync_seconds']=43200
                        c.execute('UPDATE settings SET value=?,revision=revision+1 WHERE guild=?',(canonical(cfg),row['guild']))
                        roles={r['role_id'] for r in cfg['rules'] if r['enabled'] and r['kind'] in wallet_kinds(cfg)}
                        for grant in c.execute("SELECT user,role FROM role_grants WHERE guild=? AND state='active'",(row['guild'],)).fetchall():
                            if grant['role'] in roles:
                                c.execute('INSERT OR REPLACE INTO monitoring VALUES(?,?,1)',(row['guild'],grant['user']))
                        pending=c.execute('SELECT user FROM jobs WHERE guild=? AND NOT EXISTS(SELECT 1 FROM snapshots WHERE snapshots.guild=jobs.guild AND snapshots.user=jobs.user)',(row['guild'],)).fetchall()
                        for job in pending:
                            links={r[0] for r in c.execute('SELECT kind FROM links WHERE guild=? AND user=? AND active=1',(row['guild'],job['user']))}
                            kinds=(wallet_kinds(cfg) if 'wallet' in links else set())|(account_kinds(cfg) if 'account' in links else set())
                            if kinds:c.execute('INSERT OR IGNORE INTO job_requests VALUES(?,?,?,1)',(row['guild'],job['user'],canonical(sorted(kinds))))
                    c.execute("INSERT INTO meta VALUES('role_monitor_policy','1')")
                version=c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
                if version!='1': raise Conflict('Unsupported database schema. Install a compatible release.')
        await asyncio.to_thread(init)
        os.chmod(self.path,0o600)

    async def query(self,sql,args=()):
        return await self.run(lambda c:[dict(r) for r in c.execute(sql,args).fetchall()])

    async def execute(self,sql,args=()):
        return await self.run(lambda c:c.execute(sql,args).rowcount)

    async def settings(self,guild):
        def get(c):
            row=c.execute('SELECT * FROM settings WHERE guild=?',(guild,)).fetchone()
            if not row:
                cfg=defaults(); c.execute('INSERT INTO settings VALUES(?,1,?)',(guild,canonical(cfg))); return cfg,1
            cfg=json.loads(row['value']);cfg.setdefault('wallet_transfer',False)
            return cfg,row['revision']
        return await self.run(get)

    async def save_settings(self,guild,cfg,revision,actor):
        validate(cfg)
        def save(c):
            existing=c.execute("SELECT DISTINCT CASE WHEN event_id LIKE 'solana:%' THEN 'rpc' ELSE 'platform' END AS mode FROM ledger WHERE guild=?",(guild,)).fetchall()
            if cfg['deposit_mode']!='off' and any(r['mode']!=cfg['deposit_mode'] for r in existing):
                raise Conflict('The deposit ledger already uses another accounting method. Keep that method or perform an audited ledger migration; switching could count the same payment twice.')
            cur=c.execute('UPDATE settings SET value=?,revision=revision+1 WHERE guild=? AND revision=?',(canonical(cfg),guild,revision))
            if cur.rowcount!=1: raise Conflict('Settings changed. Reopen the panel and retry.')
            c.execute('INSERT INTO audit(guild,actor,action,detail,created) VALUES(?,?,?,?,?)',(guild,actor,'settings',canonical(cfg),time.time()))
            c.execute('UPDATE jobs SET next_run=? WHERE guild=?',(time.time(),guild))
            return revision+1
        return await self.run(save)

    async def audit(self,guild,actor,action,detail):
        await self.execute('INSERT INTO audit(guild,actor,action,detail,created) VALUES(?,?,?,?,?)',(guild,actor,action,str(detail)[:100000],time.time()))

    async def links(self,guild,user):
        return await self.query('SELECT * FROM links WHERE guild=? AND user=? AND active=1 ORDER BY kind,identity',(guild,user))

    async def credit(self,guild,user,wallet,event_id,amount,source,proof):
        if type(amount) is not int or not 0<amount<=10**18: raise ValueError('Invalid deposit amount.')
        if not isinstance(event_id,str) or not event_id.startswith(('solana:','platform:')) or len(event_id)>500: raise ValueError('Invalid canonical deposit event ID.')
        def put(c):
            mode='rpc' if event_id.startswith('solana:') else 'platform'
            other=c.execute("SELECT event_id FROM ledger WHERE guild=? AND event_id NOT LIKE ? LIMIT 1",(guild,('solana:' if mode=='rpc' else 'platform:')+'%')).fetchone()
            if other: raise Conflict('Mixed deposit accounting methods require an audited migration before importing receipts.')
            old=c.execute('SELECT * FROM ledger WHERE guild=? AND event_id=?',(guild,event_id)).fetchone()
            if old:
                if (old['user'],old['wallet'],old['usd_micros']) != (user,wallet,amount):
                    raise Conflict('Deposit identity or valuation changed. Manual ledger review is required.')
                return False
            c.execute('INSERT INTO ledger VALUES(?,?,?,?,?,?,?,?)',(guild,event_id,user,wallet,amount,source,canonical(proof),time.time()))
            return True
        return await self.run(put)

    async def total(self,guild,user):
        rows=await self.query('SELECT usd_micros FROM ledger WHERE guild=? AND user=?',(guild,user))
        return sum(r['usd_micros'] for r in rows)

    async def enqueue(self,guild,user,when=None,*,scope='initial'):
        cfg,_=await self.settings(guild)
        kinds=wallet_kinds(cfg) if scope in ('wallet','hint','member') else account_kinds(cfg) if scope=='account' else wallet_kinds(cfg)|account_kinds(cfg)
        def queue(c):
            if scope=='hint':
                active=c.execute('SELECT active FROM monitoring WHERE guild=? AND user=?',(guild,user)).fetchone()
                if not active or not active['active']:return False
            self.queue_check(c,guild,user,kinds,time.time() if when is None else when)
            return True
        return await self.run(queue)

    @staticmethod
    def queue_check(c,guild,user,kinds,when):
        old=c.execute('SELECT * FROM job_requests WHERE guild=? AND user=?',(guild,user)).fetchone()
        requested=kinds|set(json.loads(old['kinds'])) if old else kinds
        c.execute('INSERT INTO job_requests VALUES(?,?,?,1) ON CONFLICT(guild,user) DO UPDATE SET kinds=excluded.kinds,version=version+1',(guild,user,canonical(sorted(requested))))
        c.execute('INSERT INTO jobs(guild,user,next_run) VALUES(?,?,?) ON CONFLICT(guild,user) DO UPDATE SET next_run=MIN(jobs.next_run,excluded.next_run)',(guild,user,when))

    async def member_refresh(self,guild,user,now=None):
        now=time.time() if now is None else now
        def queue(c):
            row=c.execute("SELECT created FROM audit WHERE guild=? AND actor=? AND action='member_refresh' ORDER BY id DESC LIMIT 1",(guild,user)).fetchone()
            if row and now-row['created']<60: raise ValueError('Your refresh is already queued. Wait one minute before requesting another.')
            c.execute("INSERT INTO audit(guild,actor,action,detail,created) VALUES(?,?,'member_refresh','Queued by member',?)",(guild,user,now))
        await self.run(queue)
        await self.enqueue(guild,user,now,scope='member')

    async def finish_check(self,guild,user,version,active,when):
        def finish(c):
            current=c.execute('SELECT version FROM job_requests WHERE guild=? AND user=?',(guild,user)).fetchone()
            if (current['version'] if current else 0)!=version:return False
            c.execute('INSERT OR REPLACE INTO monitoring VALUES(?,?,?)',(guild,user,int(active)))
            c.execute('DELETE FROM job_requests WHERE guild=? AND user=?',(guild,user))
            if active:c.execute('UPDATE jobs SET next_run=?,failures=0 WHERE guild=? AND user=?',(when,guild,user))
            else:c.execute('DELETE FROM jobs WHERE guild=? AND user=?',(guild,user))
            return True
        return await self.run(finish)

    async def start_point_batch(self,guild,actor):
        cfg,_=await self.settings(guild)
        if not account_kinds(cfg):raise ValueError('Enable a platform data source first.')
        def start(c):
            current=c.execute("SELECT id FROM point_batches WHERE guild=? AND status IN ('running','paused') ORDER BY id DESC LIMIT 1",(guild,)).fetchone()
            if current:return current['id']
            users=c.execute("SELECT DISTINCT user FROM links WHERE guild=? AND kind='account' AND active=1",(guild,)).fetchall()
            if not users:raise ValueError('No verified platform accounts are connected yet.')
            bid=c.execute("INSERT INTO point_batches(guild,actor,status,created) VALUES(?,?,'running',?)",(guild,actor,time.time())).lastrowid
            c.executemany('INSERT INTO point_batch_members(batch,user) VALUES(?,?)',[(bid,r['user']) for r in users])
            return bid
        return await self.run(start)

    async def point_progress(self,guild):
        batches=await self.query('SELECT * FROM point_batches WHERE guild=? ORDER BY id DESC LIMIT 1',(guild,))
        if not batches:return None
        counts=await self.query('SELECT state,COUNT(*) AS n FROM point_batch_members WHERE batch=? GROUP BY state',(batches[0]['id'],))
        return {**batches[0],'counts':{r['state']:r['n'] for r in counts}}

    async def backup(self,destination,guild=None):
        target=Path(destination); target.parent.mkdir(parents=True,exist_ok=True)
        async with self.lock:
            def copy():
                src=self.connect(); dst=sqlite3.connect(target)
                try:
                    src.backup(dst)
                    if guild is not None:
                        dst.execute('DELETE FROM point_batch_members WHERE batch IN (SELECT id FROM point_batches WHERE guild<>?)',(guild,))
                        for table in ('settings','audit','links','sessions','transfer_proofs','ledger','observations','checkpoints','snapshots','jobs','role_grants','deliveries','monitoring','job_requests','point_batches'):
                            dst.execute(f'DELETE FROM {table} WHERE guild<>?',(guild,))
                        dst.execute('DELETE FROM sessions')
                        dst.execute('DELETE FROM transfer_proofs WHERE used<>1')
                        dst.execute('DELETE FROM webhook_ids')
                        dst.commit()
                    if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok': raise Conflict('Backup integrity check failed.')
                finally: dst.close(); src.close()
                os.chmod(target,0o600)
            await asyncio.to_thread(copy)
        return target
